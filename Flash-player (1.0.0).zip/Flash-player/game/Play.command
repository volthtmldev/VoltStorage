#!/bin/sh
# Opens index.html in Chrome in its own profile with local-file access, so the
# page can find the library folder (library or ../library) by itself.
DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE="$HOME/.flash-player-profile"
FLAGS="--user-data-dir=$PROFILE --allow-file-access-from-files --no-first-run"
if [ "$(uname)" = "Darwin" ]; then
  open -na "Google Chrome" --args $FLAGS "file://$DIR/index.html"
else
  for b in google-chrome google-chrome-stable chromium chromium-browser; do
    if command -v "$b" >/dev/null 2>&1; then exec "$b" $FLAGS "file://$DIR/index.html"; fi
  done
  echo "Chrome/Chromium not found."
fi
