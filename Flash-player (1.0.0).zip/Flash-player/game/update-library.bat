@echo off
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 goto usepython
where py >nul 2>nul
if %errorlevel%==0 goto usepy
powershell -NoProfile -ExecutionPolicy Bypass -File update-library.ps1
goto done
:usepython
python update-library.py
goto done
:usepy
py update-library.py
:done
echo.
echo Done. Reload index.html.
pause
