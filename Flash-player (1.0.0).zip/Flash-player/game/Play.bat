@echo off
rem Opens index.html in Chrome in its own profile with local-file access, so the
rem page can find the library folder (library or ..\library) by itself.
setlocal
set "CHROME="
for %%P in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe") do (
  if exist %%P if not defined CHROME set "CHROME=%%~P"
)
if not defined CHROME (
  echo Could not find Google Chrome. Install it, or edit Play.bat to point at your browser.
  pause
  exit /b 1
)
start "" "%CHROME%" --user-data-dir="%LocalAppData%\FlashPlayerProfile" --allow-file-access-from-files --no-first-run "%~dp0index.html"
