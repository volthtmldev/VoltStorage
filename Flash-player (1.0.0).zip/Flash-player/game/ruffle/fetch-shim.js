// Lets Ruffle load its .wasm when index.html is opened directly from disk (file://),
// where Chrome blocks fetch() of local files. WASM is embedded in ruffle/wasm/*.wasm.js
(function () {
  const realFetch = window.fetch.bind(window);
  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = src; s.onload = res; s.onerror = () => rej(new Error("Cannot load " + src));
      document.head.appendChild(s);
    });
  }
  window.fetch = async function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || String(input);
    const m = /([^\/\\?#]+\.wasm)(?:[?#].*)?$/.exec(url);
    if (m && location.protocol === "file:") {
      const name = m[1];
      window.__ruffleWasm = window.__ruffleWasm || {};
      if (!window.__ruffleWasm[name]) {
        const base = document.currentScript ? document.currentScript.src : null;
        await loadScript(shimBase + "wasm/" + name + ".js");
      }
      const bin = atob(window.__ruffleWasm[name]);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      window.__ruffleWasm[name] = null;
      return new Response(bytes, { status: 200, headers: { "Content-Type": "application/wasm" } });
    }
    return realFetch(input, init);
  };
  const shimBase = document.currentScript.src.replace(/[^\/]*$/, "");
})();
