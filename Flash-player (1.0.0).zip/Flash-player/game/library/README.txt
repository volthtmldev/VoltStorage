Put your .swf games in this folder (or in a "library" folder one level up: ../library).
Open the player with Play.bat (Windows) / Play.command (Mac) and they appear automatically.
