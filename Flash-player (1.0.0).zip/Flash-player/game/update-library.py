#!/usr/bin/env python3
"""Scans the folder this file is in for .swf files and packs them so index.html
can load them straight from disk (browsers can't list or read files by themselves).
Run it again whenever you add, remove or rename a .swf."""
import os, sys, re, json, time, base64, shutil, unicodedata

here = os.path.dirname(os.path.abspath(__file__))
out = os.path.join(here, "library-data")

def swfs(d):
    return sorted((f for f in os.listdir(d)
                   if f.lower().endswith(".swf") and os.path.isfile(os.path.join(d, f))),
                  key=lambda s: unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower() or s.lower())

entries = [(True, os.path.join(here, f), f) for f in swfs(here)]
# library folder: settings.txt "libraryPath" ("auto" = library, then ../library)
cands = ["library", "../library"]
try:
    m = re.search(r'^\s*libraryPath\s*=\s*"([^"]*)"', open(os.path.join(here, "settings.txt"), encoding="utf-8").read(), re.M)
    if m and m.group(1).strip() and m.group(1).strip().lower() != "auto":
        cands = [m.group(1).strip()]
except OSError:
    pass
chosen = None
for c in cands:                      # prefer the first folder that actually has games
    lib = os.path.normpath(os.path.join(here, c))
    if os.path.isdir(lib):
        if swfs(lib):
            chosen = lib
            break
        chosen = chosen or lib
if chosen:
    print("Library folder:", chosen)
    entries += [(False, os.path.join(chosen, f), f) for f in swfs(chosen)]

shutil.rmtree(out, ignore_errors=True)
os.makedirs(out)
index = []
for i, (is_root, path, name) in enumerate(entries):
    with open(path, "rb") as fh:
        b64 = base64.b64encode(fh.read()).decode("ascii")
    rel = "library-data/%04d.js" % i
    with open(os.path.join(here, rel), "w") as fh:
        fh.write('window.__swfData=window.__swfData||{};window.__swfData[%d]="%s";' % (i, b64))
    index.append({"id": i, "name": name, "root": is_root, "file": rel})
with open(os.path.join(out, "index.js"), "w") as fh:
    fh.write("window.__swfLib=" + json.dumps(index) + ";")
    fh.write("window.__swfMeta=" + json.dumps({"generated": int(time.time() * 1000), "folder": os.path.relpath(chosen, here) if chosen else ""}) + ";")

print("Packed %d game(s):" % len(index))
for e in index:
    print("  " + ("" if e["root"] else "library/") + e["name"])
if not index:
    print("No .swf files found. Put them next to index.html (or in the 'library' folder).")
