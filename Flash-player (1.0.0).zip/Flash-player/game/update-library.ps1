# Windows fallback for update-library.py (no Python needed).
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $here "library-data"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
New-Item -ItemType Directory -Path $out | Out-Null
$entries = @()
Get-ChildItem -LiteralPath $here -Filter *.swf -File | Sort-Object Name | ForEach-Object { $entries += ,@($true, $_.FullName, $_.Name) }
$cands = @("library", "../library")
$st = Join-Path $here "settings.txt"
if (Test-Path $st) {
  $mm = [regex]::Match([IO.File]::ReadAllText($st), '(?m)^\s*libraryPath\s*=\s*"([^"]*)"')
  if ($mm.Success -and $mm.Groups[1].Value.Trim() -ne "" -and $mm.Groups[1].Value.Trim().ToLower() -ne "auto") { $cands = @($mm.Groups[1].Value.Trim()) }
}
$lib = $null
foreach ($c in $cands) { $p = Join-Path $here $c; if (Test-Path $p -PathType Container) { $lib = (Resolve-Path $p).Path; break } }
if ($lib) {
  Get-ChildItem -LiteralPath $lib -Filter *.swf -File | Sort-Object Name | ForEach-Object { $entries += ,@($false, $_.FullName, $_.Name) }
}
$index = @()
for ($i = 0; $i -lt $entries.Count; $i++) {
  $e = $entries[$i]
  $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($e[1]))
  $rel = "library-data/{0:D4}.js" -f $i
  $js = 'window.__swfData=window.__swfData||{};window.__swfData[' + $i + ']="' + $b64 + '";'
  [IO.File]::WriteAllText((Join-Path $here $rel), $js)
  $index += [ordered]@{ id = $i; name = $e[2]; root = [bool]$e[0]; file = $rel }
}
$json = if ($index.Count -eq 0) { "[]" } else { ConvertTo-Json -InputObject @($index) -Compress }
$json = [regex]::Replace($json, '[^\x00-\x7F]', { param($m) '\u{0:x4}' -f [int][char]$m.Value })
$gen = [int64]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
[IO.File]::WriteAllText((Join-Path $out "index.js"), "window.__swfLib=" + $json + ";window.__swfMeta={generated:" + $gen + "};")
Write-Host ("Packed {0} game(s)." -f $index.Count)
